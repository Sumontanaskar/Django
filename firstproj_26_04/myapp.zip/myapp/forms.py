from .models import Dreamreal

def handle_uploaded_file(f):
    i = 0
    for chunk in f:
        chunk = chunk.split(',')
        data = Dreamreal()
        if i != 0:
            print chunk[0], chunk[1]
            data.date = chunk[0]
            data.host = chunk[1]
            data.din = chunk[2]
            data.dout = chunk[3]
            data.dtot = chunk[4]
            data.save()
        i += 1


