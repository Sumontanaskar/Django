from django.shortcuts import render, render_to_response
from django.http import Http404, HttpResponseRedirect
from .models import Dreamreal
from django.core.files.storage import FileSystemStorage
from .forms import handle_uploaded_file


# Create your views here.
def index(request):
    all_host = Dreamreal.objects.all()
    return render(request, 'myapp/index.html', {'all_host': all_host})

#Details id replied
def detail(request, host_id):
    try:
        host = Dreamreal.objects.get(pk=host_id)
    except Dreamreal.DoesNotExist:
        raise Http404("Host not exist")
    return render(request, 'myapp/details.html', {'host': host})

def results(request):
    if request.method == "POST":
        hostname = request.POST['hostname']
        date = request.POST['date']
        format = type(date)
        all_host = Dreamreal.objects.all()
        return render(request, 'myapp/results.html', {'all_host': all_host, 'hostname': hostname, 'date': date, 'format': format})

#Upload file
def upload(request):
    if request.method == 'POST' and request.FILES['myfile']:
        myfile = request.FILES['myfile']
        handle_uploaded_file(request.FILES['myfile'])
        fs = FileSystemStorage()
        filename = fs.save(myfile.name, myfile)
        uploaded_file_url = fs.url(filename)
        return render(request, 'myapp/upload.html', {
            'uploaded_file_url': uploaded_file_url
        })
    all_host = Dreamreal.objects.all()
    return render(request, 'myapp/upload.html', {'all_host': all_host})